package com.perfulandia.msvc_comprobante_venta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcComprobanteVentaApplicationTests {

	@Test
	void contextLoads() {
	}

}
