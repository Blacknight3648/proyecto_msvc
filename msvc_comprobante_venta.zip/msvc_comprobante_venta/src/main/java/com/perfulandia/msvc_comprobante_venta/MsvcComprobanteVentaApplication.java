package com.perfulandia.msvc_comprobante_venta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsvcComprobanteVentaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsvcComprobanteVentaApplication.class, args);
	}

}
