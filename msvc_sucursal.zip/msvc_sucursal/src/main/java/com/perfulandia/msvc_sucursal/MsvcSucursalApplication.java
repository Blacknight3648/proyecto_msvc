package com.perfulandia.msvc_sucursal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsvcSucursalApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsvcSucursalApplication.class, args);
	}

}
